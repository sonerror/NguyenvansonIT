﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using De_2.Models;

namespace De_2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        QLBHContext Q = new QLBHContext();
        public MainWindow()
        {
            InitializeComponent();
            disp_cbb();
            disp();
        }
        private void disp_cbb()
        {
            var query = from n in Q.NhomHangs
                        select n.TenNhomHang;
            cbb.ItemsSource = query.ToList();
        }
        private void disp()
        {
            var query = from sp in Q.SanPhams
                        join nh in Q.NhomHangs on sp.MaNhomHang equals nh.MaNhomHang
                        where sp.SoLuongBan > 0
                        orderby sp.DonGia descending
                        select new
                        {
                            MaSP = sp.MaSp,
                            TenSP = sp.TenSanPham,
                            DG = sp.DonGia,
                            SLB = sp.SoLuongBan,
                            NH = nh.TenNhomHang,
                            TB = sp.DonGia * sp.SoLuongBan
                        };
            DSSP.ItemsSource = query.ToList();
        }

        private void DSSP_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            var item = DSSP.SelectedItem;
            if (item != null)
            {
                string t = (DSSP.SelectedCells[4].Column.GetCellContent(item) as TextBlock).Text;
                cbb.SelectedItem = t;
            }
        }
        private void clear()
        {
            msp.Clear();
            tsp.Clear();
            dg.Clear();
            slb.Clear();
            cbb.SelectedIndex = -1;
        }
        private void check()
        {
            try
            {
                if (msp.Text.CompareTo("") == 0)
                {
                    msp.Focus();
                    throw new Exception("Mã sản phẩm không được để trống!");
                }
                if (tsp.Text.CompareTo("") == 0)
                {
                    tsp.Focus();
                    throw new Exception("Tên sản phẩm không được để trống!");
                }
                if (dg.Text.CompareTo("") == 0)
                {
                    dg.Focus();
                    throw new Exception("Đơn giá không được để trống!");
                }
                if (slb.Text.CompareTo("") == 0)
                {
                    slb.Focus();
                    throw new Exception("Số lượng bán không được để trống!");
                }
                if (int.Parse(dg.Text) < 0)
                {
                    dg.Focus();
                    throw new Exception("Sai định dạng đơn giá!");
                }
                if (int.Parse(slb.Text) < 1)
                {
                    slb.Focus();
                    throw new Exception("Số lượng bán phải >=1!");
                }
                if (cbb.SelectedIndex == -1)
                {
                    throw new Exception("Chưa chọn nhóm hàng!");
                }
            }
            catch (Exception exe)
            {
                MessageBox.Show(exe.Message, "Cảnh báo", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void them_Click(object sender, RoutedEventArgs e)
        {
            check();
            try
            {
                var spc = from sp in Q.SanPhams
                          where sp.MaSp.CompareTo(int.Parse(msp.Text)) == 0
                          select sp;
                if (spc.Count() > 0)
                {
                    msp.Focus();
                    throw new Exception("Mã sản phẩm đã tồn tại!");
                }
                var manh = (from nh in Q.NhomHangs
                            where nh.TenNhomHang == cbb.Text
                            select nh.MaNhomHang).Single();
                SanPham s = new SanPham();
                s.MaSp = int.Parse(msp.Text);
                s.TenSanPham = tsp.Text;
                s.DonGia = int.Parse(dg.Text);
                s.SoLuongBan = int.Parse(slb.Text);
                s.MaNhomHang = Convert.ToInt32(manh);
                try
                {
                    Q.SanPhams.Add(s);
                    throw new Exception("Thêm thành công sản phẩm mới!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Thông báo", MessageBoxButton.OK, MessageBoxImage.None);
                }
                Q.SaveChanges();
                disp();
                clear();
            }
            catch (Exception exe)
            {
                MessageBox.Show(exe.Message, "Cảnh báo", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void tim_Click(object sender, RoutedEventArgs e)
        {
            Window1 w = new Window1();
            w.ShowDialog();
        }
    }
}
