﻿using System;
using System.Collections.Generic;

namespace De_2.Models
{
    public partial class NhomHang
    {
        public int MaNhomHang { get; set; }
        public string TenNhomHang { get; set; } = null!;
    }
}
