﻿using System;
using System.Collections.Generic;

namespace De_2.Models
{
    public partial class SanPham
    {
        public int MaSp { get; set; }
        public string TenSanPham { get; set; } = null!;
        public int DonGia { get; set; }
        public int SoLuongBan { get; set; }
        public int MaNhomHang { get; set; }
    }
}
