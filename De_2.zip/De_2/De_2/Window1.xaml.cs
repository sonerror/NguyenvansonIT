﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using De_2.Models;

namespace De_2
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        QLBHContext Q = new QLBHContext();
        public Window1()
        {
            InitializeComponent();
            disp_cbb();
            disp();
        }
        private void disp_cbb()
        {
            var query = from n in Q.NhomHangs
                        select n.TenNhomHang;
            cbb2.ItemsSource = query.ToList();
        }
        private void disp()
        {
            cbb2.SelectedIndex = 0;
            var query = from sp in Q.SanPhams
                        join nh in Q.NhomHangs on sp.MaNhomHang equals nh.MaNhomHang
                        where nh.MaNhomHang == 1
                        select new
                        {
                            MaSP = sp.MaSp,
                            TenSP = sp.TenSanPham,
                            DG = sp.DonGia,
                            SLB = sp.SoLuongBan,
                            NH = nh.TenNhomHang,
                            TB = sp.DonGia * sp.SoLuongBan
                        };
            DSSP2.ItemsSource = query.ToList();
        }

        private void tim_Click(object sender, RoutedEventArgs e)
        {
            String t = cbb2.Text;
            var query = from sp in Q.SanPhams
                        join nh in Q.NhomHangs on sp.MaNhomHang equals nh.MaNhomHang
                        where nh.TenNhomHang.CompareTo(t) == 0
                        select new
                        {
                            MaSP = sp.MaSp,
                            TenSP = sp.TenSanPham,
                            DG = sp.DonGia,
                            SLB = sp.SoLuongBan,
                            NH = nh.TenNhomHang,
                            TB = sp.DonGia * sp.SoLuongBan
                        };
            DSSP2.ItemsSource = query.ToList();
        }
    }
}
